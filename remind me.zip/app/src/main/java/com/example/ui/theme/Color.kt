package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Softer, serene M3 Light Palette (Calming Slate-Indigo & Soft Sage)
val PrimaryLight = Color(0xFF3E5F7E)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFE4ECF4)
val OnPrimaryContainerLight = Color(0xFF132738)

val SecondaryLight = Color(0xFF4F7065)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFDFECE6)
val OnSecondaryContainerLight = Color(0xFF152A22)

val TertiaryLight = Color(0xFF6B5E7E)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFEEE7F6)
val OnTertiaryContainerLight = Color(0xFF261A36)

val BackgroundLight = Color(0xFFF7F9FA)
val OnBackgroundLight = Color(0xFF1E2328)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF1E2328)
val SurfaceVariantLight = Color(0xFFEFF3F6)
val OnSurfaceVariantLight = Color(0xFF55606B)
val OutlineLight = Color(0xFFDCE2E8)
val OutlineVariantLight = Color(0xFFE7ECEF)

// Softer, gentle M3 Dark Palette (Warm Charcoal & Muted Pastel Accents)
val PrimaryDark = Color(0xFFA1BED8)
val OnPrimaryDark = Color(0xFF0F2B44)
val PrimaryContainerDark = Color(0xFF26435F)
val OnPrimaryContainerDark = Color(0xFFD7E6F4)

val SecondaryDark = Color(0xFFA3C6B9)
val OnSecondaryDark = Color(0xFF1C372E)
val SecondaryContainerDark = Color(0xFF345147)
val OnSecondaryContainerDark = Color(0xFFDFECE6)

val TertiaryDark = Color(0xFFC7B8DF)
val OnTertiaryDark = Color(0xFF332746)
val TertiaryContainerDark = Color(0xFF4E4162)
val OnTertiaryContainerDark = Color(0xFFEEE7F6)

val BackgroundDark = Color(0xFF14171A)
val OnBackgroundDark = Color(0xFFE3E7EB)
val SurfaceDark = Color(0xFF1B1F24)
val OnSurfaceDark = Color(0xFFE3E7EB)
val SurfaceVariantDark = Color(0xFF252A30)
val OnSurfaceVariantDark = Color(0xFFA6B0BA)
val OutlineDark = Color(0xFF3A424B)
val OutlineVariantDark = Color(0xFF2E343C)
