package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircleOutline
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.TaskCategory
import com.example.data.TaskEntity
import com.example.ui.components.AddEditTaskDialog
import com.example.ui.components.NotificationPermissionBanner
import com.example.ui.components.TaskCard
import com.example.ui.components.TaskDashboardHeader
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskScreen(
    viewModel: TaskViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var showAddDialog by remember { mutableStateOf(false) }
    var taskToEdit by remember { mutableStateOf<TaskEntity?>(null) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.TaskAlt,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "TaskPulse",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.toggleDarkMode() },
                        modifier = Modifier.testTag("theme_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (uiState.isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle Theme",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    taskToEdit = null
                    showAddDialog = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .testTag("add_task_fab")
                    .size(56.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Schedule New Task",
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isExpandedScreen = maxWidth >= 768.dp

            if (isExpandedScreen) {
                // Adaptive Two-Column Layout for Tablets, Foldables & Desktops
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    // Left Column: Overview Pane
                    Column(
                        modifier = Modifier
                            .width(360.dp)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        NotificationPermissionBanner()

                        TaskDashboardHeader(
                            stats = uiState.stats,
                            onTestNotificationClick = {
                                viewModel.triggerQuickSampleNotification()
                                scope.launch {
                                    snackbarHostState.showSnackbar("Push Notification triggered with Mark Done & Snooze actions!")
                                }
                            }
                        )

                        // Categories Section in Left Pane
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    width = 1.dp,
                                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(20.dp)
                                ),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Categories",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (uiState.selectedCategory == null)
                                        MaterialTheme.colorScheme.primaryContainer
                                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.setCategory(null) }
                                ) {
                                    Text(
                                        text = "All Categories",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (uiState.selectedCategory == null) FontWeight.SemiBold else FontWeight.Normal,
                                        color = if (uiState.selectedCategory == null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                                    )
                                }

                                TaskCategory.entries.forEach { category ->
                                    val isSelected = uiState.selectedCategory == category
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isSelected) category.containerColor else MaterialTheme.colorScheme.surface,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { viewModel.setCategory(if (isSelected) null else category) }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = category.icon,
                                                contentDescription = null,
                                                tint = category.color,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Text(
                                                text = category.displayName,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                                color = if (isSelected) category.color else MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Right Column: Search, Tabs & Task List
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    ) {
                        SearchBarSection(
                            query = uiState.searchQuery,
                            onQueryChange = { viewModel.setSearchQuery(it) }
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        TabsSection(
                            selectedTab = uiState.selectedTab,
                            stats = uiState.stats,
                            totalTasksCount = uiState.tasks.size,
                            onTabSelected = { viewModel.setTab(it) }
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        TaskListContent(
                            isLoading = uiState.isLoading,
                            tasks = uiState.filteredTasks,
                            searchQuery = uiState.searchQuery,
                            selectedTab = uiState.selectedTab,
                            onToggleCompleted = { viewModel.toggleCompleted(it) },
                            onEditClick = {
                                taskToEdit = it
                                showAddDialog = true
                            },
                            onDeleteClick = {
                                viewModel.deleteTask(it)
                                scope.launch { snackbarHostState.showSnackbar("Task deleted") }
                            },
                            onSnoozeClick = {
                                viewModel.snoozeTask(it, 10)
                                scope.launch { snackbarHostState.showSnackbar("Reminder snoozed for 10 minutes") }
                            },
                            onTestNotificationClick = {
                                viewModel.triggerInstantNotification(it)
                                scope.launch { snackbarHostState.showSnackbar("Alert triggered for '${it.title}'") }
                            },
                            onScheduleFirstTask = {
                                taskToEdit = null
                                showAddDialog = true
                            }
                        )
                    }
                }
            } else {
                // Adaptive Mobile / Handheld Layout (Centered max-width 640dp for clean proportions)
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .widthIn(max = 640.dp)
                    ) {
                        NotificationPermissionBanner()

                        TaskDashboardHeader(
                            stats = uiState.stats,
                            onTestNotificationClick = {
                                viewModel.triggerQuickSampleNotification()
                                scope.launch {
                                    snackbarHostState.showSnackbar("Push Notification triggered with Mark Done & Snooze actions!")
                                }
                            }
                        )

                        SearchBarSection(
                            query = uiState.searchQuery,
                            onQueryChange = { viewModel.setSearchQuery(it) }
                        )

                        TabsSection(
                            selectedTab = uiState.selectedTab,
                            stats = uiState.stats,
                            totalTasksCount = uiState.tasks.size,
                            onTabSelected = { viewModel.setTab(it) }
                        )

                        CategoryFilterChipsRow(
                            selectedCategory = uiState.selectedCategory,
                            onCategorySelected = { viewModel.setCategory(it) }
                        )

                        TaskListContent(
                            isLoading = uiState.isLoading,
                            tasks = uiState.filteredTasks,
                            searchQuery = uiState.searchQuery,
                            selectedTab = uiState.selectedTab,
                            onToggleCompleted = { viewModel.toggleCompleted(it) },
                            onEditClick = {
                                taskToEdit = it
                                showAddDialog = true
                            },
                            onDeleteClick = {
                                viewModel.deleteTask(it)
                                scope.launch { snackbarHostState.showSnackbar("Task deleted") }
                            },
                            onSnoozeClick = {
                                viewModel.snoozeTask(it, 10)
                                scope.launch { snackbarHostState.showSnackbar("Reminder snoozed for 10 minutes") }
                            },
                            onTestNotificationClick = {
                                viewModel.triggerInstantNotification(it)
                                scope.launch { snackbarHostState.showSnackbar("Alert triggered for '${it.title}'") }
                            },
                            onScheduleFirstTask = {
                                taskToEdit = null
                                showAddDialog = true
                            }
                        )
                    }
                }
            }
        }
    }

    // Add / Edit Dialog
    if (showAddDialog) {
        AddEditTaskDialog(
            initialTask = taskToEdit,
            onDismiss = {
                showAddDialog = false
                taskToEdit = null
            },
            onSave = { title, desc, scheduledMillis, category, recurrence, customDays ->
                if (taskToEdit != null) {
                    val updated = taskToEdit!!.copy(
                        title = title,
                        description = desc,
                        scheduledTimeMillis = scheduledMillis,
                        category = category.name,
                        recurrence = recurrence.name,
                        customDays = customDays.joinToString(",")
                    )
                    viewModel.updateTask(updated)
                    scope.launch {
                        snackbarHostState.showSnackbar("Task updated & reminder rescheduled")
                    }
                } else {
                    viewModel.addTask(
                        title = title,
                        description = desc,
                        scheduledMillis = scheduledMillis,
                        category = category,
                        recurrence = recurrence,
                        customDays = customDays
                    )
                    scope.launch {
                        snackbarHostState.showSnackbar("Task scheduled with push notification!")
                    }
                }
                showAddDialog = false
                taskToEdit = null
            }
        )
    }
}

@Composable
private fun SearchBarSection(
    query: String,
    onQueryChange: (String) -> Unit
) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        placeholder = {
            Text(
                "Search tasks, routines, or notes...",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
        },
        leadingIcon = {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
        },
        trailingIcon = {
            if (query.isNotBlank()) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Clear search",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedContainerColor = MaterialTheme.colorScheme.surface,
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f),
            focusedBorderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .testTag("search_tasks_input")
    )
}

@Composable
private fun TabsSection(
    selectedTab: TaskTab,
    stats: TaskStats,
    totalTasksCount: Int,
    onTabSelected: (TaskTab) -> Unit
) {
    PrimaryTabRow(
        selectedTabIndex = selectedTab.ordinal,
        containerColor = MaterialTheme.colorScheme.background,
        modifier = Modifier.fillMaxWidth()
    ) {
        TaskTab.entries.forEach { tab ->
            val badgeCount = when (tab) {
                TaskTab.TODAY -> stats.todayPendingCount
                TaskTab.UPCOMING -> stats.upcomingCount
                TaskTab.COMPLETED -> stats.totalCompletedCount
                TaskTab.ALL -> totalTasksCount
            }

            Tab(
                selected = selectedTab == tab,
                onClick = { onTabSelected(tab) },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = tab.title,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Medium,
                            color = if (selectedTab == tab) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (badgeCount > 0) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Badge(
                                containerColor = if (selectedTab == tab)
                                    MaterialTheme.colorScheme.primaryContainer
                                else
                                    MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = badgeCount.toString(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selectedTab == tab)
                                        MaterialTheme.colorScheme.onPrimaryContainer
                                    else
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                },
                modifier = Modifier.testTag("tab_${tab.name.lowercase()}")
            )
        }
    }
}

@Composable
private fun CategoryFilterChipsRow(
    selectedCategory: TaskCategory?,
    onCategorySelected: (TaskCategory?) -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        item {
            FilterChip(
                selected = selectedCategory == null,
                onClick = { onCategorySelected(null) },
                label = { Text("All", style = MaterialTheme.typography.labelSmall) },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("category_filter_all")
            )
        }
        items(TaskCategory.entries.toTypedArray()) { category ->
            val isSelected = selectedCategory == category
            FilterChip(
                selected = isSelected,
                onClick = { onCategorySelected(if (isSelected) null else category) },
                label = { Text(category.displayName, style = MaterialTheme.typography.labelSmall) },
                leadingIcon = {
                    Icon(
                        imageVector = category.icon,
                        contentDescription = null,
                        modifier = Modifier.size(13.dp),
                        tint = if (isSelected) MaterialTheme.colorScheme.primary else category.color
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = category.containerColor,
                    selectedLabelColor = category.color
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("category_filter_${category.name.lowercase()}")
            )
        }
    }
}

@Composable
private fun TaskListContent(
    isLoading: Boolean,
    tasks: List<TaskEntity>,
    searchQuery: String,
    selectedTab: TaskTab,
    onToggleCompleted: (TaskEntity) -> Unit,
    onEditClick: (TaskEntity) -> Unit,
    onDeleteClick: (TaskEntity) -> Unit,
    onSnoozeClick: (TaskEntity) -> Unit,
    onTestNotificationClick: (TaskEntity) -> Unit,
    onScheduleFirstTask: () -> Unit
) {
    if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(strokeWidth = 3.dp)
        }
    } else if (tasks.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(28.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    modifier = Modifier.size(68.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = when (selectedTab) {
                                TaskTab.COMPLETED -> Icons.Default.CheckCircleOutline
                                TaskTab.UPCOMING -> Icons.Default.CalendarMonth
                                else -> Icons.Default.TaskAlt
                            },
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                }

                Text(
                    text = when {
                        searchQuery.isNotBlank() -> "No matching tasks"
                        selectedTab == TaskTab.COMPLETED -> "No completed tasks yet"
                        selectedTab == TaskTab.UPCOMING -> "No upcoming tasks scheduled"
                        else -> "No tasks pending for today"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = if (searchQuery.isNotBlank()) {
                        "Try searching for another keyword or clear the active filter."
                    } else {
                        "Tap the schedule button below to set your reminders and daily agenda."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                Button(
                    onClick = onScheduleFirstTask,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("empty_state_add_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Schedule Task", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 84.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(
                items = tasks,
                key = { it.id }
            ) { task ->
                TaskCard(
                    task = task,
                    onToggleCompleted = onToggleCompleted,
                    onEditClick = onEditClick,
                    onDeleteClick = onDeleteClick,
                    onSnoozeClick = onSnoozeClick,
                    onTestNotificationClick = onTestNotificationClick
                )
            }
        }
    }
}
