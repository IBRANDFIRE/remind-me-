package com.example.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Work
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class TaskCategory(
    val displayName: String,
    val color: Color,
    val containerColor: Color,
    val icon: ImageVector
) {
    WORK(
        displayName = "Work",
        color = Color(0xFF386A94), // Soft Slate Blue
        containerColor = Color(0xFFEAF1F7),
        icon = Icons.Default.Work
    ),
    PERSONAL(
        displayName = "Personal",
        color = Color(0xFF3E7C57), // Soft Sage Green
        containerColor = Color(0xFFEBF4EE),
        icon = Icons.Default.Person
    ),
    HEALTH(
        displayName = "Health",
        color = Color(0xFFB85953), // Soft Terracotta Rose
        containerColor = Color(0xFFF9EFEB),
        icon = Icons.Default.Favorite
    ),
    STUDY(
        displayName = "Study",
        color = Color(0xFFA66E2B), // Soft Warm Ochre
        containerColor = Color(0xFFFAF3E8),
        icon = Icons.Default.Book
    ),
    ERRANDS(
        displayName = "Errands",
        color = Color(0xFF755B94), // Soft Heather Violet
        containerColor = Color(0xFFF2EDF8),
        icon = Icons.Default.ShoppingCart
    ),
    GENERAL(
        displayName = "General",
        color = Color(0xFF5A6872), // Soft Muted Slate
        containerColor = Color(0xFFEEF2F5),
        icon = Icons.Default.CheckCircle
    );

    companion object {
        fun fromName(name: String?): TaskCategory {
            return entries.firstOrNull { it.name.equals(name, ignoreCase = true) || it.displayName.equals(name, ignoreCase = true) }
                ?: GENERAL
        }
    }
}
