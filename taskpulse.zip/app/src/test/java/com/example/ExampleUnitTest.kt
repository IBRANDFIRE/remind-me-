package com.example

import com.example.data.RecurrenceType
import com.example.util.DateTimeUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class ExampleUnitTest {
    @Test
    fun testRecurrenceNone_preservesTime() {
        val now = System.currentTimeMillis()
        val futureTime = now + 100000
        val calculated = RecurrenceType.calculateNextTrigger(futureTime, RecurrenceType.NONE, emptySet(), now)
        assertEquals(futureTime, calculated)
    }

    @Test
    fun testRecurrenceDaily_advancesToFuture() {
        val now = System.currentTimeMillis()
        // Past time: 2 hours ago
        val pastTime = now - (2 * 60 * 60 * 1000)
        val nextTrigger = RecurrenceType.calculateNextTrigger(pastTime, RecurrenceType.DAILY, emptySet(), now)
        assertTrue(nextTrigger > now)
    }

    @Test
    fun testRecurrenceFormatting() {
        val dailyStr = DateTimeUtils.formatRecurrenceRule("DAILY", "")
        assertEquals("Every day", dailyStr)

        val oneTimeStr = DateTimeUtils.formatRecurrenceRule("NONE", "")
        assertEquals("One-time", oneTimeStr)

        val customStr = DateTimeUtils.formatRecurrenceRule("CUSTOM", "2,4,6")
        assertEquals("Mon, Wed, Fri", customStr)
    }
}
