package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateTimeUtils {

    fun formatScheduledDateTime(millis: Long): String {
        val taskCal = Calendar.getInstance().apply { timeInMillis = millis }
        val nowCal = Calendar.getInstance()

        val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
        val timeStr = timeFormat.format(Date(millis))

        val isToday = taskCal.get(Calendar.YEAR) == nowCal.get(Calendar.YEAR) &&
                taskCal.get(Calendar.DAY_OF_YEAR) == nowCal.get(Calendar.DAY_OF_YEAR)

        val tomorrowCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
        val isTomorrow = taskCal.get(Calendar.YEAR) == tomorrowCal.get(Calendar.YEAR) &&
                taskCal.get(Calendar.DAY_OF_YEAR) == tomorrowCal.get(Calendar.DAY_OF_YEAR)

        val yesterdayCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        val isYesterday = taskCal.get(Calendar.YEAR) == yesterdayCal.get(Calendar.YEAR) &&
                taskCal.get(Calendar.DAY_OF_YEAR) == yesterdayCal.get(Calendar.DAY_OF_YEAR)

        return when {
            isToday -> "Today at $timeStr"
            isTomorrow -> "Tomorrow at $timeStr"
            isYesterday -> "Yesterday at $timeStr"
            else -> {
                val dateFormat = SimpleDateFormat("EEE, MMM d, h:mm a", Locale.getDefault())
                dateFormat.format(Date(millis))
            }
        }
    }

    fun formatDateOnly(millis: Long): String {
        val dateFormat = SimpleDateFormat("EEE, MMM d, yyyy", Locale.getDefault())
        return dateFormat.format(Date(millis))
    }

    fun formatTimeOnly(millis: Long): String {
        val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
        return timeFormat.format(Date(millis))
    }

    fun getDayName(calendarDayOfWeek: Int): String {
        return when (calendarDayOfWeek) {
            Calendar.SUNDAY -> "Sun"
            Calendar.MONDAY -> "Mon"
            Calendar.TUESDAY -> "Tue"
            Calendar.WEDNESDAY -> "Wed"
            Calendar.THURSDAY -> "Thu"
            Calendar.FRIDAY -> "Fri"
            Calendar.SATURDAY -> "Sat"
            else -> ""
        }
    }

    fun formatRecurrenceRule(recurrence: String, customDays: String): String {
        return when (recurrence.uppercase()) {
            "NONE" -> "One-time"
            "DAILY" -> "Every day"
            "WEEKLY" -> "Every week"
            "CUSTOM" -> {
                val days = customDays.split(",")
                    .mapNotNull { it.trim().toIntOrNull() }
                    .map { getDayName(it) }
                if (days.isNotEmpty()) days.joinToString(", ") else "Custom"
            }
            else -> recurrence
        }
    }
}
