package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.example.data.TaskDatabase
import com.example.notification.NotificationHelper
import com.example.notification.TaskAlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class NotificationActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_MARK_DONE = "com.example.taskpulse.ACTION_MARK_DONE"
        const val ACTION_SNOOZE = "com.example.taskpulse.ACTION_SNOOZE"
        const val EXTRA_TASK_ID = "EXTRA_TASK_ID"
        const val SNOOZE_DURATION_MILLIS = 10 * 60 * 1000L // 10 minutes
    }

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
        if (taskId == -1L) return

        val action = intent.action ?: return
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = TaskDatabase.getDatabase(context)
                val task = db.taskDao().getTaskById(taskId)

                when (action) {
                    ACTION_MARK_DONE -> {
                        NotificationHelper.dismissNotification(context, taskId)
                        TaskAlarmScheduler.cancelTask(context, taskId)
                        db.taskDao().markTaskCompleted(taskId, System.currentTimeMillis())

                        withContext(Dispatchers.Main) {
                            Toast.makeText(
                                context,
                                "Task marked as completed!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    ACTION_SNOOZE -> {
                        NotificationHelper.dismissNotification(context, taskId)
                        val snoozeUntil = System.currentTimeMillis() + SNOOZE_DURATION_MILLIS
                        db.taskDao().snoozeTask(taskId, snoozeUntil)

                        task?.let {
                            val snoozedTask = it.copy(
                                scheduledTimeMillis = snoozeUntil,
                                snoozeCount = it.snoozeCount + 1
                            )
                            TaskAlarmScheduler.scheduleTask(context, snoozedTask)
                        }

                        withContext(Dispatchers.Main) {
                            Toast.makeText(
                                context,
                                "Reminder snoozed for 10 minutes",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
