package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.RecurrenceType
import com.example.data.TaskDatabase
import com.example.notification.NotificationHelper
import com.example.notification.TaskAlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_TRIGGER_TASK = "com.example.taskpulse.ACTION_TRIGGER_TASK"
        const val EXTRA_TASK_ID = "EXTRA_TASK_ID"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getLongExtra(EXTRA_TASK_ID, -1L)
        if (taskId == -1L) return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = TaskDatabase.getDatabase(context)
                val task = db.taskDao().getTaskById(taskId)
                if (task != null && !task.isCompleted) {
                    // Show notification
                    NotificationHelper.showTaskNotification(context, task)

                    // If recurring, calculate and schedule next cycle
                    val recurrence = task.getRecurrenceEnum()
                    if (recurrence != RecurrenceType.NONE) {
                        val nextTrigger = RecurrenceType.calculateNextTrigger(
                            scheduledMillis = task.scheduledTimeMillis,
                            recurrence = recurrence,
                            customDays = task.getCustomDaysSet(),
                            fromMillis = System.currentTimeMillis() + 60_000 // calculate from 1 minute ahead
                        )
                        val updated = task.copy(scheduledTimeMillis = nextTrigger)
                        db.taskDao().updateTask(updated)
                        TaskAlarmScheduler.scheduleTask(context, updated)
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
