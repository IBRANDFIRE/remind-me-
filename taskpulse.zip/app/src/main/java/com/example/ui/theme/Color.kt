package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val PrimaryLight = Color(0xFF3751FF)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFDFE4FF)
val OnPrimaryContainerLight = Color(0xFF001453)

val SecondaryLight = Color(0xFF00897B)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFB2DFDB)
val OnSecondaryContainerLight = Color(0xFF003731)

val TertiaryLight = Color(0xFF7C4DFF)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFEDE7F6)
val OnTertiaryContainerLight = Color(0xFF280680)

val BackgroundLight = Color(0xFFF8F9FD)
val OnBackgroundLight = Color(0xFF191C20)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF191C20)
val SurfaceVariantLight = Color(0xFFEEF0F6)
val OnSurfaceVariantLight = Color(0xFF44474E)
val OutlineLight = Color(0xFFD6DAE4)

// Dark Theme Colors
val PrimaryDark = Color(0xFF90A4FF)
val OnPrimaryDark = Color(0xFF00227B)
val PrimaryContainerDark = Color(0xFF1C34A8)
val OnPrimaryContainerDark = Color(0xFFDFE4FF)

val SecondaryDark = Color(0xFF4DB6AC)
val OnSecondaryDark = Color(0xFF003731)
val SecondaryContainerDark = Color(0xFF004D40)
val OnSecondaryContainerDark = Color(0xFFB2DFDB)

val TertiaryDark = Color(0xFFB39DDB)
val OnTertiaryDark = Color(0xFF311B92)
val TertiaryContainerDark = Color(0xFF512DA8)
val OnTertiaryContainerDark = Color(0xFFEDE7F6)

val BackgroundDark = Color(0xFF121418)
val OnBackgroundDark = Color(0xFFE2E2E8)
val SurfaceDark = Color(0xFF1A1D24)
val OnSurfaceDark = Color(0xFFE2E2E8)
val SurfaceVariantDark = Color(0xFF262A34)
val OnSurfaceVariantDark = Color(0xFFC4C6D0)
val OutlineDark = Color(0xFF3F4452)
