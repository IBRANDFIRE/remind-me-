package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.RecurrenceType
import com.example.data.TaskCategory
import com.example.data.TaskDatabase
import com.example.data.TaskEntity
import com.example.data.TaskRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

enum class TaskTab(val title: String) {
    TODAY("Today"),
    UPCOMING("Upcoming"),
    COMPLETED("Completed"),
    ALL("All Tasks")
}

data class TaskStats(
    val todayPendingCount: Int = 0,
    val todayCompletedCount: Int = 0,
    val todayTotalCount: Int = 0,
    val todayProgress: Float = 0f,
    val upcomingCount: Int = 0,
    val totalCompletedCount: Int = 0
)

data class TaskUiState(
    val tasks: List<TaskEntity> = emptyList(),
    val filteredTasks: List<TaskEntity> = emptyList(),
    val stats: TaskStats = TaskStats(),
    val selectedTab: TaskTab = TaskTab.TODAY,
    val selectedCategory: TaskCategory? = null,
    val searchQuery: String = "",
    val isDarkMode: Boolean = false,
    val isLoading: Boolean = false
)

class TaskViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TaskRepository
    private val selectedTabFlow = MutableStateFlow(TaskTab.TODAY)
    private val selectedCategoryFlow = MutableStateFlow<TaskCategory?>(null)
    private val searchQueryFlow = MutableStateFlow("")
    private val isDarkModeFlow = MutableStateFlow(false)

    init {
        val db = TaskDatabase.getDatabase(application)
        repository = TaskRepository(application, db.taskDao())
        seedSampleTasksIfEmpty()
    }

    val uiState: StateFlow<TaskUiState> = combine(
        repository.allTasks,
        selectedTabFlow,
        selectedCategoryFlow,
        searchQueryFlow,
        isDarkModeFlow
    ) { allTasks, tab, category, search, darkMode ->

        // Calculate Stats
        val todayTasks = allTasks.filter { it.isScheduledToday() }
        val todayCompleted = todayTasks.count { it.isCompleted }
        val todayPending = todayTasks.count { !it.isCompleted }
        val todayTotal = todayTasks.size
        val progress = if (todayTotal > 0) todayCompleted.toFloat() / todayTotal else 0f
        val upcomingCount = allTasks.count { it.isUpcoming() && !it.isCompleted }
        val totalCompleted = allTasks.count { it.isCompleted }

        val stats = TaskStats(
            todayPendingCount = todayPending,
            todayCompletedCount = todayCompleted,
            todayTotalCount = todayTotal,
            todayProgress = progress,
            upcomingCount = upcomingCount,
            totalCompletedCount = totalCompleted
        )

        // Filter by Tab
        val tabFiltered = when (tab) {
            TaskTab.TODAY -> allTasks.filter { it.isScheduledToday() || (!it.isCompleted && it.isOverdue()) }
            TaskTab.UPCOMING -> allTasks.filter { it.isUpcoming() && !it.isCompleted }
            TaskTab.COMPLETED -> allTasks.filter { it.isCompleted }
            TaskTab.ALL -> allTasks
        }

        // Filter by Category
        val categoryFiltered = if (category != null) {
            tabFiltered.filter { it.getCategoryEnum() == category }
        } else {
            tabFiltered
        }

        // Filter by Search Query
        val searchFiltered = if (search.isNotBlank()) {
            val q = search.trim().lowercase()
            categoryFiltered.filter {
                it.title.lowercase().contains(q) || it.description.lowercase().contains(q)
            }
        } else {
            categoryFiltered
        }

        TaskUiState(
            tasks = allTasks,
            filteredTasks = searchFiltered,
            stats = stats,
            selectedTab = tab,
            selectedCategory = category,
            searchQuery = search,
            isDarkMode = darkMode,
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TaskUiState(isLoading = true)
    )

    fun setTab(tab: TaskTab) {
        selectedTabFlow.value = tab
    }

    fun setCategory(category: TaskCategory?) {
        selectedCategoryFlow.value = category
    }

    fun setSearchQuery(query: String) {
        searchQueryFlow.value = query
    }

    fun toggleDarkMode() {
        isDarkModeFlow.value = !isDarkModeFlow.value
    }

    fun addTask(
        title: String,
        description: String,
        scheduledMillis: Long,
        category: TaskCategory,
        recurrence: RecurrenceType,
        customDays: Set<Int>
    ) {
        viewModelScope.launch {
            val task = TaskEntity(
                title = title.trim(),
                description = description.trim(),
                scheduledTimeMillis = scheduledMillis,
                category = category.name,
                recurrence = recurrence.name,
                customDays = customDays.joinToString(",")
            )
            repository.insertTask(task)
        }
    }

    fun updateTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.updateTask(task)
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    fun toggleCompleted(task: TaskEntity) {
        viewModelScope.launch {
            repository.toggleCompleted(task)
        }
    }

    fun snoozeTask(task: TaskEntity, minutes: Int = 10) {
        viewModelScope.launch {
            repository.snoozeTask(task, minutes)
        }
    }

    fun triggerInstantNotification(task: TaskEntity) {
        repository.triggerInstantNotification(task)
    }

    fun triggerQuickSampleNotification() {
        val sample = TaskEntity(
            id = System.currentTimeMillis() % 100000,
            title = "Reminder: Drink a Glass of Water",
            description = "Stay hydrated and take a quick 2-minute stretch break!",
            scheduledTimeMillis = System.currentTimeMillis(),
            category = TaskCategory.HEALTH.name,
            recurrence = RecurrenceType.DAILY.name
        )
        repository.triggerInstantNotification(sample)
    }

    private fun seedSampleTasksIfEmpty() {
        viewModelScope.launch {
            val db = TaskDatabase.getDatabase(getApplication())
            val existing = db.taskDao().getPendingTasksSync()
            if (existing.isEmpty()) {
                val now = Calendar.getInstance()

                // Task 1: Today morning
                val t1Time = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 9)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                }.timeInMillis

                // Task 2: Today afternoon
                val t2Time = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 14)
                    set(Calendar.MINUTE, 30)
                    set(Calendar.SECOND, 0)
                }.timeInMillis

                // Task 3: Today evening
                val t3Time = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 19)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                }.timeInMillis

                // Task 4: Tomorrow
                val t4Time = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, 1)
                    set(Calendar.HOUR_OF_DAY, 10)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                }.timeInMillis

                repository.insertTask(
                    TaskEntity(
                        title = "Team Standup & Sprint Planning",
                        description = "Review weekly backlog priorities and update tickets on JIRA.",
                        scheduledTimeMillis = t1Time,
                        category = TaskCategory.WORK.name,
                        recurrence = RecurrenceType.DAILY.name
                    )
                )

                repository.insertTask(
                    TaskEntity(
                        title = "Drink Water & 15m Walk",
                        description = "Take a hydration break and do light stretching.",
                        scheduledTimeMillis = t2Time,
                        category = TaskCategory.HEALTH.name,
                        recurrence = RecurrenceType.DAILY.name
                    )
                )

                repository.insertTask(
                    TaskEntity(
                        title = "Study Kotlin Coroutines & Flow",
                        description = "Read chapter 4 on StateFlow and Channel buffering.",
                        scheduledTimeMillis = t3Time,
                        category = TaskCategory.STUDY.name,
                        recurrence = RecurrenceType.WEEKLY.name
                    )
                )

                repository.insertTask(
                    TaskEntity(
                        title = "Grocery Shopping: Fruits & Almond Milk",
                        description = "Pick up bananas, spinach, and whole grain oats from local market.",
                        scheduledTimeMillis = t4Time,
                        category = TaskCategory.ERRANDS.name,
                        recurrence = RecurrenceType.NONE.name
                    )
                )
            }
        }
    }
}
