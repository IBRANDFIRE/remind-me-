package com.example.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Work
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class TaskCategory(
    val displayName: String,
    val color: Color,
    val containerColor: Color,
    val icon: ImageVector
) {
    WORK(
        displayName = "Work",
        color = Color(0xFF1E88E5), // Blue
        containerColor = Color(0xFFE3F2FD),
        icon = Icons.Default.Work
    ),
    PERSONAL(
        displayName = "Personal",
        color = Color(0xFF43A047), // Green
        containerColor = Color(0xFFE8F5E9),
        icon = Icons.Default.Person
    ),
    HEALTH(
        displayName = "Health",
        color = Color(0xFFE53935), // Red / Coral
        containerColor = Color(0xFFFFEBEE),
        icon = Icons.Default.Favorite
    ),
    STUDY(
        displayName = "Study",
        color = Color(0xFFFB8C00), // Amber / Orange
        containerColor = Color(0xFFFFF3E0),
        icon = Icons.Default.Book
    ),
    ERRANDS(
        displayName = "Errands",
        color = Color(0xFF8E24AA), // Purple
        containerColor = Color(0xFFF3E5F5),
        icon = Icons.Default.ShoppingCart
    ),
    GENERAL(
        displayName = "General",
        color = Color(0xFF546E7A), // Slate
        containerColor = Color(0xFFECEFF1),
        icon = Icons.Default.CheckCircle
    );

    companion object {
        fun fromName(name: String?): TaskCategory {
            return entries.firstOrNull { it.name.equals(name, ignoreCase = true) || it.displayName.equals(name, ignoreCase = true) }
                ?: GENERAL
        }
    }
}
