package com.example.data

import android.content.Context
import com.example.notification.NotificationHelper
import com.example.notification.TaskAlarmScheduler
import kotlinx.coroutines.flow.Flow

class TaskRepository(
    private val context: Context,
    private val taskDao: TaskDao
) {
    val allTasks: Flow<List<TaskEntity>> = taskDao.getAllTasks()
    val pendingTasks: Flow<List<TaskEntity>> = taskDao.getPendingTasks()
    val completedTasks: Flow<List<TaskEntity>> = taskDao.getCompletedTasks()

    suspend fun getTaskById(id: Long): TaskEntity? = taskDao.getTaskById(id)

    suspend fun insertTask(task: TaskEntity): Long {
        val id = taskDao.insertTask(task)
        val createdTask = task.copy(id = id)
        TaskAlarmScheduler.scheduleTask(context, createdTask)
        return id
    }

    suspend fun updateTask(task: TaskEntity) {
        taskDao.updateTask(task)
        if (task.isCompleted) {
            TaskAlarmScheduler.cancelTask(context, task.id)
            NotificationHelper.dismissNotification(context, task.id)
        } else {
            TaskAlarmScheduler.scheduleTask(context, task)
        }
    }

    suspend fun deleteTask(task: TaskEntity) {
        TaskAlarmScheduler.cancelTask(context, task.id)
        NotificationHelper.dismissNotification(context, task.id)
        taskDao.deleteTask(task)
    }

    suspend fun toggleCompleted(task: TaskEntity) {
        if (task.isCompleted) {
            taskDao.markTaskIncomplete(task.id)
            val updated = task.copy(isCompleted = false, completedAtMillis = null)
            TaskAlarmScheduler.scheduleTask(context, updated)
        } else {
            taskDao.markTaskCompleted(task.id, System.currentTimeMillis())
            TaskAlarmScheduler.cancelTask(context, task.id)
            NotificationHelper.dismissNotification(context, task.id)
        }
    }

    suspend fun snoozeTask(task: TaskEntity, minutes: Int = 10) {
        val newTime = System.currentTimeMillis() + (minutes * 60 * 1000L)
        taskDao.snoozeTask(task.id, newTime)
        NotificationHelper.dismissNotification(context, task.id)
        val snoozed = task.copy(scheduledTimeMillis = newTime, snoozeCount = task.snoozeCount + 1)
        TaskAlarmScheduler.scheduleTask(context, snoozed)
    }

    fun triggerInstantNotification(task: TaskEntity) {
        NotificationHelper.showTaskNotification(context, task)
    }
}
