package com.example.data

import java.util.Calendar

enum class RecurrenceType(val displayName: String) {
    NONE("One-time"),
    DAILY("Daily"),
    WEEKLY("Weekly"),
    CUSTOM("Custom Days");

    companion object {
        fun fromString(value: String?): RecurrenceType {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: NONE
        }

        /**
         * Calculates the next trigger time in epoch millis from now, or returns the original time if it's in the future and non-repeating.
         * For repeating tasks that are in the past, finds the next valid instance.
         */
        fun calculateNextTrigger(
            scheduledMillis: Long,
            recurrence: RecurrenceType,
            customDays: Set<Int>, // 1 = Sunday, 2 = Monday, ... 7 = Saturday (Calendar.SUNDAY..SATURDAY)
            fromMillis: Long = System.currentTimeMillis()
        ): Long {
            if (scheduledMillis > fromMillis) {
                return scheduledMillis
            }

            // If it's one-time and past, no next occurrence
            if (recurrence == NONE) {
                return scheduledMillis
            }

            val targetCal = Calendar.getInstance().apply { timeInMillis = scheduledMillis }
            val hour = targetCal.get(Calendar.HOUR_OF_DAY)
            val minute = targetCal.get(Calendar.MINUTE)
            val second = targetCal.get(Calendar.SECOND)

            val nowCal = Calendar.getInstance().apply { timeInMillis = fromMillis }

            when (recurrence) {
                DAILY -> {
                    val candidate = Calendar.getInstance().apply {
                        timeInMillis = fromMillis
                        set(Calendar.HOUR_OF_DAY, hour)
                        set(Calendar.MINUTE, minute)
                        set(Calendar.SECOND, second)
                        set(Calendar.MILLISECOND, 0)
                    }
                    if (candidate.timeInMillis <= fromMillis) {
                        candidate.add(Calendar.DAY_OF_YEAR, 1)
                    }
                    return candidate.timeInMillis
                }
                WEEKLY -> {
                    val dayOfWeek = targetCal.get(Calendar.DAY_OF_WEEK)
                    val candidate = Calendar.getInstance().apply {
                        timeInMillis = fromMillis
                        set(Calendar.HOUR_OF_DAY, hour)
                        set(Calendar.MINUTE, minute)
                        set(Calendar.SECOND, second)
                        set(Calendar.MILLISECOND, 0)
                    }
                    while (candidate.timeInMillis <= fromMillis || candidate.get(Calendar.DAY_OF_WEEK) != dayOfWeek) {
                        candidate.add(Calendar.DAY_OF_YEAR, 1)
                    }
                    return candidate.timeInMillis
                }
                CUSTOM -> {
                    if (customDays.isEmpty()) {
                        // Fallback to daily
                        return calculateNextTrigger(scheduledMillis, DAILY, emptySet(), fromMillis)
                    }
                    val candidate = Calendar.getInstance().apply {
                        timeInMillis = fromMillis
                        set(Calendar.HOUR_OF_DAY, hour)
                        set(Calendar.MINUTE, minute)
                        set(Calendar.SECOND, second)
                        set(Calendar.MILLISECOND, 0)
                    }
                    var daysChecked = 0
                    while (daysChecked < 14) {
                        if (candidate.timeInMillis > fromMillis && customDays.contains(candidate.get(Calendar.DAY_OF_WEEK))) {
                            return candidate.timeInMillis
                        }
                        candidate.add(Calendar.DAY_OF_YEAR, 1)
                        daysChecked++
                    }
                    return candidate.timeInMillis
                }
                NONE -> return scheduledMillis
            }
        }
    }
}
