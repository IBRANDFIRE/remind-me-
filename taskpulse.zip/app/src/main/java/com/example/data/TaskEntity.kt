package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Calendar

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val scheduledTimeMillis: Long,
    val category: String = TaskCategory.GENERAL.name,
    val recurrence: String = RecurrenceType.NONE.name,
    val customDays: String = "", // e.g. "2,4,6" where 2=Monday, 4=Wednesday, 6=Friday (Calendar.DAY_OF_WEEK)
    val isCompleted: Boolean = false,
    val completedAtMillis: Long? = null,
    val snoozeCount: Int = 0,
    val createdAtMillis: Long = System.currentTimeMillis()
) {
    fun getCategoryEnum(): TaskCategory = TaskCategory.fromName(category)

    fun getRecurrenceEnum(): RecurrenceType = RecurrenceType.fromString(recurrence)

    fun getCustomDaysSet(): Set<Int> {
        if (customDays.isBlank()) return emptySet()
        return customDays.split(",")
            .mapNotNull { it.trim().toIntOrNull() }
            .toSet()
    }

    /**
     * Checks if this task is scheduled for today (calendar day match)
     */
    fun isScheduledToday(): Boolean {
        val taskCal = Calendar.getInstance().apply { timeInMillis = scheduledTimeMillis }
        val nowCal = Calendar.getInstance()
        return taskCal.get(Calendar.YEAR) == nowCal.get(Calendar.YEAR) &&
                taskCal.get(Calendar.DAY_OF_YEAR) == nowCal.get(Calendar.DAY_OF_YEAR)
    }

    /**
     * Checks if task is scheduled for future (after today)
     */
    fun isUpcoming(): Boolean {
        val taskCal = Calendar.getInstance().apply { timeInMillis = scheduledTimeMillis }
        val nowCal = Calendar.getInstance()
        if (taskCal.get(Calendar.YEAR) > nowCal.get(Calendar.YEAR)) return true
        if (taskCal.get(Calendar.YEAR) == nowCal.get(Calendar.YEAR)) {
            return taskCal.get(Calendar.DAY_OF_YEAR) > nowCal.get(Calendar.DAY_OF_YEAR)
        }
        return false
    }

    /**
     * Checks if task is overdue (past scheduled time and not completed)
     */
    fun isOverdue(): Boolean {
        return !isCompleted && scheduledTimeMillis < System.currentTimeMillis()
    }
}
